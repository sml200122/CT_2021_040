package Q_03;
import java.util.Scanner;
public class Q3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter temperature in degrees Celsius: ");
        double celsius = scanner.nextDouble();

        double fahrenheit = (1.8 * celsius) + 32;


        System.out.println("\nTemperature in degrees Fahrenheit: " + fahrenheit);

        scanner.close();
    }
}
